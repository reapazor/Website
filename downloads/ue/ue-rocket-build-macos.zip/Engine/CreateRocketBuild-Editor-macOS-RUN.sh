#!/bin/bash

# Definitions
EngineBuildFolder="/Users/reapazor/Workspaces/dotBunny/Dethol/Engine/Engine/Build/BatchFiles/"
BuildDefinition="/Users/reapazor/Workspaces/dotBunny/Dethol/Scripts/Engine/Config/InstalledEngineBuild.xml"
OutputFolder="/Users/reapazor/Workspaces/dotBunny/Dethol/Game/Engine/"

# Make local to script directory for some reason
cd "$(dirname "$0")"
clear

# Change to UE folder
cd "$EngineBuildFolder"

# Build IT!
 ./RunUAT.sh BuildGraph -target="Make Installed Build Mac" \
    -script="$BuildDefinition" \
    -set:BuiltDirectory="$OutputFolder" \
    -set:WithMac=true \
    -set:WithWin64=true \
    -set:WithAndroid=false \
    -set:WithIOS=false \
    -set:WithTVOS=false \
    -set:WithLinux=true \
    -set:WithHTML5=false \
    -set:WithSwitch=false \
    -set:WithDDC=false \

# Run Unreal (First Run Takes A While)
cd "$OutputFolder"
cd "LocalBuilds/Engine/Mac/Engine/Binaries/Mac/"
open ./UE4Editor.app/Contents/MacOS/UE4Editor
